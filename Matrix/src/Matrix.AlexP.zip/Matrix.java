import java.util.ArrayList;
import java.util.Random;

/*
 * Alex Pavel Matrix Project
 */


public class Matrix {

	ArrayList<ArrayList<Double>> myMatrix;
	ArrayList<ArrayList<Double>> myResultMatrix;
	int myMatrixRow;
	int myMatrixColumn;

	public Matrix(int row, int column) {
		initMyMatrix(row, column);
	}

	public void multMatrix(Matrix change) {
		if (canMultiply(change)) {
			myResultMatrix = new ArrayList<ArrayList<Double>>();
			for (int i = 0; i < myMatrixRow; i++) {
				myResultMatrix.add(new ArrayList<Double>());
			}
			double results = 0;
			for (int r = 0; r < myMatrixRow; r++) {
				for (int rr = 0; rr < myMatrixRow; rr++){
					for (int g = 0; g < myMatrixColumn; g++) {
						results += myMatrix.get(r).get(g) * change.getArray().get(g).get(rr);
					}
					myResultMatrix.get(r).add(results);
					results = 0;
				}
			}
			printResultDetail("*", change);
		}
		else{
			System.out.println("The product does not exist!");
		}
	}

	public void divMatrix() {

	}

	public boolean canMultiply(Matrix change) {
		int changeRow = change.getArray().size();
		int changeCol = change.getArray().get(0).size();
		if (changeRow == myMatrixColumn && changeCol == myMatrixRow) {
			return true;
		}
		else{
			return false;
		}

	}

	public void invMatrix() {

	}
	public void addMatrix(Matrix change) {
		myResultMatrix = new ArrayList<ArrayList<Double>>();
		for (int i = 0; i < myMatrixRow; i++) {
			myResultMatrix.add(new ArrayList<Double>());
		}
		int changeRow = change.getArray().size();
		int changeCol = change.getArray().get(0).size();
		if (changeCol == myMatrixColumn && changeRow == myMatrixRow) {
			for (int i = 0; i < myMatrixRow; i++) {
				for (int h = 0; h < myMatrixColumn; h++) {
					myResultMatrix.get(i).add(myMatrix.get(i).get(h) + change.getArray().get(i).get(h));
				}
			}
			printResultDetail("+", change);
		}
		else{
			System.out.println("The sum does not exist!");
		}

	}

	public void resetMyMatrix() {
		myMatrix = new ArrayList<>();
		for (int i = 0; i < myMatrixRow; i++) {
			myMatrix.add(new ArrayList<Double>());
			for (int h = 0; h < myMatrixColumn; h++) {
				myMatrix.get(i).add(h, (double) 0);
			}
		}
		System.out.println("\n\nReset myMatrix to ");
		for (int i = 0; i < myMatrixRow; i++) {
			System.out.print(myMatrix.get(i).toString());
			System.out.println();
		}
		System.out.println();
	}

	public ArrayList<ArrayList<Double>> getArray() {
		return myMatrix;
	}

	public void initMyMatrix(int row, int column) {
		myMatrixRow = row;
		myMatrixColumn = column;
		myResultMatrix = new ArrayList<>();
		myMatrix = new ArrayList<>();
		for (int i = 0; i < myMatrixRow; i++) {
			myMatrix.add(new ArrayList<Double>());
			for (int h = 0; h < myMatrixColumn; h++) {
				myMatrix.get(i).add(h, (double) new Random().nextInt(8) + 1);
			}
		}
		//		for (int i = 0; i < myMatrixRow; i++) {
		//			System.out.println();
		//			System.out.print(myMatrix.get(i).toString());
		//		}
	}

	public void printResultDetail(String operation, Matrix change) {
		int size = myMatrixRow;
		if (myMatrixColumn > size) {
			size = myMatrixColumn;
		}
		for (int i = 0; i < size; i++) {
			//			System.out.println(myMatrix.size());
			//			System.out.println(size);
			System.out.println();
			if (myMatrix.size() > i) {
				System.out.print(myMatrix.get(i).toString() + " ");
			}
			else {
				double spaces = (myMatrix.get(0).size())*4 + 4;
				for (int g = 3; g < myMatrixColumn; g++) {
					spaces += 1;
				}
				for (int h = 0; h < spaces; h++) {
					System.out.print(" ");
				}
			}
			if (i == 0) {
				System.out.print(operation + " ");
			}
			else {
				System.out.print("  ");
			}
			if (change.getArray().size() > i) {
				System.out.print(change.getArray().get(i).toString() + " ");
			}
			if (i == 0) {
				System.out.print("= ");
			}
			else {
				System.out.print("  ");
			}
			if (myResultMatrix.size() > i) {
				System.out.print(myResultMatrix.get(i).toString() + " ");
			}
		}
		System.out.println();
	}

	public static void main(String[] args) {
//		Make Matrix Object
		Matrix m1 = new Matrix(2, 3);
		Matrix m2 = new Matrix(3, 2);
//		Output Matrix 1
		System.out.print("Matrix 1 is:");
		for (int i = 0; i < m1.getArray().size(); i++) {
			System.out.println();
			System.out.print(m1.getArray().get(i).toString());
		}
		System.out.println("\n");
//		Output Matrix 2
		System.out.print("Matrix 2 is: ");
		for (int i = 0; i < m2.getArray().size(); i++) {
			System.out.println();
			System.out.print(m2.getArray().get(i).toString());
		}
		System.out.println("\n");
//		Add Matrices
		m1.addMatrix(m2);
//		Multiply Matrices
		m1.multMatrix(m2);
	}

}
