import java.util.Arrays;
import java.util.Random;


public class SortSearch {

	static int[] myStuff;
	boolean reset;

	public SortSearch() {
		reset = true;
	}

	public void bubbleSort(int[] sortArr, boolean ascending) {
		if (ascending) {
			while (reset == true) {
				reset = false;
				for (int i = 1; i < sortArr.length; i++) {
					if (sortArr[i] < sortArr[i - 1]) {
						System.out.println("Current array is " + Arrays.toString(sortArr));
						System.out.println("Switch pos " + i + " {value " + sortArr[i] + "} with pos " + (i - 1) + " {value " + sortArr[i - 1] + "}");
						int upperVal = sortArr[i - 1];
						int lowerVal = sortArr[i];
						sortArr[i] = upperVal;
						sortArr[i - 1] = lowerVal;
						reset = true;
						System.out.println("Changed array is " + Arrays.toString(sortArr) + "\n");
					}
				}
			}
		}
		else {
			while (reset == true) {
				reset = false;
				for (int i = 1; i < sortArr.length; i++) {
					if (sortArr[i] > sortArr[i - 1]) {
						System.out.println("Current array is " + Arrays.toString(sortArr));
						System.out.println("Switch pos "+ i + " {value " + sortArr[i]+ "} with pos " + (i-1) + " {value " + sortArr[i - 1]+ "}");
						int upperVal = sortArr[i - 1];
						int lowerVal = sortArr[i];
						sortArr[i] = upperVal;
						sortArr[i - 1] = lowerVal;
						reset = true;
						System.out.println("Changed array is " + Arrays.toString(sortArr) + "\n");
					}
				}
			}
		}
	}

	public void selectionSort(int[] sortArr, boolean ascending) {
		if (ascending) {
			for (int i = 0; i < sortArr.length - 1; i++) {
				System.out.println("Current array is " + Arrays.toString(sortArr));
				int minVal = sortArr[i];
				int pos = i;
				for (int g = i + 1; g < sortArr.length; g++) {
					if (minVal >= sortArr[g]) {
						minVal = sortArr[g];
						pos = g;
					}
				}
				System.out.println("Moved position " + pos + " {value " + sortArr[pos] +"} to pos " + i);
				sortArr[pos] = sortArr[i];
				sortArr[i] = minVal;
				System.out.println("Changed array is " + Arrays.toString(sortArr) + "\n");
			}
		}
		else {
			for (int i = 0; i < sortArr.length - 1; i++) {
				System.out.println("Current array is " + Arrays.toString(sortArr));
				int minVal = sortArr[i];
				int pos = i;
				for (int g = i + 1; g < sortArr.length; g++) {
					if (minVal <= sortArr[g]) {
						minVal = sortArr[g];
						pos = g;
					}
				}
				System.out.println("Moved position " + pos + " {value " + sortArr[pos] +"} to pos " + i);
				sortArr[pos] = sortArr[i];
				sortArr[i] = minVal;
				System.out.println("Changed array is " + Arrays.toString(sortArr) + "\n");
			}
		}
	}

	public void insertionSort(int[] sortArr, boolean ascending) {
		if (ascending) {
			for (int i = 1; i < sortArr.length; i++) {
				for (int g = i; g > 0; g = g - 1) {
					if (sortArr[g] < sortArr[g - 1]) {
						int switched = sortArr[g - 1];
						System.out.println("Current array is " + Arrays.toString(sortArr));
						System.out.println("Switched pos " + (g-1) +" {value = " + sortArr[g - 1] + "} with pos " + (g) +" {value = " + sortArr[g] +"}");
						sortArr[g - 1] = sortArr[g];
						sortArr[g] = switched;
						System.out.println("Changed array is " + Arrays.toString(sortArr) + "\n");
					}
				}
			}
		}
		else {
			for (int i = 1; i < sortArr.length; i++) {
				for (int g = i; g > 0; g = g - 1) {
					if (sortArr[g] > sortArr[g - 1]) {
						int switched = sortArr[g - 1];
						System.out.println("Current array is " + Arrays.toString(sortArr));
						System.out.println("Switched pos " + (g-1) +" {value = " + sortArr[g - 1] + "} with pos " + (g) +" {value = " + sortArr[g] +"}");
						sortArr[g - 1] = sortArr[g];
						sortArr[g] = switched;
						System.out.println("Changed array is " + Arrays.toString(sortArr) + "\n");
					}
				}
			}
		}
	}

	public void unknown(int w[],int i) {
		//Prints the array in reverse.
		if (i >= w.length-1)
			System.out.print(w[i]+", ");
		else
		{
			unknown(w,i+1);
			System.out.print(w[i]+", ");
		}
	}

	public static void main(String[] args) {
		//myStuff = new int[10];
		//for (int i = 0; i < myStuff.length; i++) {
		//	myStuff[i] = new Random().nextInt(10);
		//}
		//System.out.println("Initial array was " + Arrays.toString(myStuff) + "\n");
		SortSearch sorter = new SortSearch();
		//sorter.bubbleSort(myStuff, true);
	    //sorter.selectionSort(myStuff, true);
		//sorter.insertionSort(myStuff, true);
		//System.out.println("My sorted array is " + Arrays.toString(myStuff));
		int[] unknownArr = new int[1000];
		for(int i = 0; i < unknownArr.length; i++) {
			unknownArr[i] = new Random().nextInt(100);
		}
		System.out.println("Old Unknown: "+Arrays.toString(unknownArr));
		sorter.unknown(unknownArr, 0);
		//System.out.println("New Unknown: "+Arrays.toString(unknownArr));
	}

}
