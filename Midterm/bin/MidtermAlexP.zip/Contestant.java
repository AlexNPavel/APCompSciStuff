
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Alex Pavel
 */
public class Contestant extends Thread{
    
    ArrayList<Integer> bucket;
    ArrayList<ArrayList> oldBuckets;
    PointsTray pTray;
    int roundNumber;
    PointsMaker pMaker;
    
    public Contestant(PointsMaker poMaker, PointsTray poTray) {
        pMaker = poMaker;
        pTray = poTray;
        bucket = new ArrayList();
        bucket.add(0);
    }
    
    @Override
    public void run() {
        
        oldBuckets = new ArrayList();
        roundNumber = 0;
        while(true) {
            System.out.println("Contestant run");
            bucket = new ArrayList();
            while(roundNumber == pTray.getRound()) {
                try {
                    sleep(new Random().nextInt(2400) + 100);
                } catch (InterruptedException ex) {
                    System.out.println("Contestant Sleep Error");
                }
                bucket.add(pTray.takeValue());
            }
            oldBuckets.add(bucket);
        }
    }
    
    public int totalScore() {
        int totScore = 0;
        for (int i = 0; i < bucket.size(); i++) {
            totScore += bucket.get(i);
        }
        return totScore;
    }
    
}
