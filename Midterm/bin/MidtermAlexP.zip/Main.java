/**
 *
 * @author Alex Pavel
 */
public class Main {
    
    static PointsMaker pMaker;
    static Contestant c01;
    static Contestant c02;
    static Contestant c03;
    static Contestant c04;
    static Contestant c05;
    static Contestant c06;
    static Contestant c07;
    static Contestant c08;
    static Contestant c09;
    static Contestant c10;
    static PointsTray poTray;
    
    public static void main(String[] args) {
        Contestant[] contestants = new Contestant[10];
        contestants[0] = c01;
        contestants[1] = c02;
        contestants[2] = c03;
        contestants[3] = c04;
        contestants[4] = c05;
        contestants[5] = c06;
        contestants[6] = c07;
        contestants[7] = c08;
        contestants[8] = c09;
        contestants[9] = c10;
        poTray = new PointsTray();
        pMaker = new PointsMaker(poTray, contestants);
        c01 = new Contestant(pMaker, poTray);
        c02 = new Contestant(pMaker, poTray);
        c03 = new Contestant(pMaker, poTray);
        c04 = new Contestant(pMaker, poTray);
        c05 = new Contestant(pMaker, poTray);
        c06 = new Contestant(pMaker, poTray);
        c07 = new Contestant(pMaker, poTray);
        c08 = new Contestant(pMaker, poTray);
        c09 = new Contestant(pMaker, poTray);
        c10 = new Contestant(pMaker, poTray);
        pMaker.start();
        c01.start();
        c02.start();
        c03.start();
        c04.start();
        c05.start();
        c06.start();
        c07.start();
        c08.start();
        c09.start();
        c10.start();
    }
    
}
