
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Alex Pavel
 */
public class PointsMaker extends Thread {
    
    int round;
    PointsTray pTray;
    Contestant[] contestants;
    
    public PointsMaker(PointsTray poTray, Contestant[] c) {
        round = 0;
        int size = new Random().nextInt(15) + 10;
        int[] values = new int[size];
        pTray = poTray;
        contestants = c;
    }
    
    @Override
    public void run() {
        while(true) {
            if(round == 0) {                
                int size = new Random().nextInt(15) + 10;
                int[] values = new int[size];
                pTray.reset(values, this);
            }
            else{
                if (pTray.inactive()) {
                    round++;
                    ArrayList<Integer> highest = new ArrayList();
                    highest.add(0);
                    for(int i = 0; i < 10; i++) {
                        if (contestants[i].totalScore() > highest.get(0)) {
                            highest = new ArrayList();
                            highest.add(i);
                        }
                        else if (contestants[i].totalScore() == highest.get(0)) {
                            highest.add(i);
                        }
                    }
                    for (int i = 0; i < highest.size(); i++) {
                        if (i == 0) {
                            System.out.print("The highest score was "+ contestants[highest.get(i)] + " by contestant "+ highest.get(i));
                        }
                        else {
                            System.out.print(" tied with contestant "+ highest.get(i));
                        }
                    }
                    System.out.println("");
                    int size = new Random().nextInt(15) + 10;
                    int[] values = new int[size];
                    pTray.reset(values, this);
                }
                else {
                    try {
                        sleep(new Random().nextInt(1500) + 1000);
                    } catch (InterruptedException ex) {
                        System.out.println("PointsMaker sleep error");
                    }
                }
            }
        }
    }
}
