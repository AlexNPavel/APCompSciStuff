
import java.util.Random;

/**
 *
 * @author Alex Pavel
 */
public class PointsTray {
    
    int[] values;
    int round;
    boolean inactive;
    PointsMaker pMaker;
    
    public PointsTray() {
        inactive = true;
    }   
    
    public void reset(int[] givenArray, PointsMaker poMaker) {
        values = givenArray;
        inactive = false;
        pMaker = poMaker;
        for (int i = 0; i < values.length; i++) {
            values[i] = new Random().nextInt(50);
        }
    }
    
    public int getRound() {
        return round;
    }
    
    public int takeValue() {
        int random = new Random().nextInt(values.length - 1);
        int returnVal = 0;
        if (values[random] > 0) {
            returnVal = values[random];
            values[random] = -10 * round;
        }
        else{
            returnVal = values[random];
        }
        if (check() == false) {}
        else {
            inactive = true;
            round++;
        }
        return returnVal;
    }
    
    boolean check() {
        boolean returnVal = false;
        for (int i = 0; i < values.length; i++) {
            if (values[i] > 0) {
                returnVal = true;
                break;
            }
        }
        return returnVal;
    }
    
    public boolean inactive() {
        return inactive;
    }
    
}
